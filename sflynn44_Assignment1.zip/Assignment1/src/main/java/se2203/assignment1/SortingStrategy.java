package se2203.assignment1;

public interface SortingStrategy extends Runnable{

    static void sort(int[] numbers){}
}
